UltrAES从V1.1开始增加了脚本运行功能。
对于脚本文件，可以在命令行中使用 [UltrAES.exe -s 脚本文件名] 运行脚本。
sample.txt用于测试脚本运行，但需将其和test.txt及example.jpg一起放在UltrAES.exe的工作目录下。
测试完后，可以用 [清理测试文件.bat] 清理运行产生的文件。